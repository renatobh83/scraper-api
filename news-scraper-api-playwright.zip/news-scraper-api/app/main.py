import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Query

from app.browser import BrowserManager
from app.config import settings
from app.models import HealthResponse, NewsResponse
from app.scrapers import SCRAPERS
from app.scrapers.base import ScraperError


browser_manager = BrowserManager()
scrape_semaphore = asyncio.Semaphore(settings.max_concurrent_scrapes)
cache: dict[tuple[str, int], tuple[float, NewsResponse]] = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    # O Chromium é iniciado de forma preguiçosa na primeira chamada a /news.
    yield
    await browser_manager.close()


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="API inicial para coleta de notícias com Playwright.",
    lifespan=lifespan,
)


@app.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    return HealthResponse(status="ok", version=settings.app_version)


@app.get("/news", response_model=NewsResponse)
async def news(
    source: str = Query("investing", min_length=1, max_length=30),
    limit: int = Query(20, ge=1, le=settings.max_news_items),
) -> NewsResponse:
    source_key = source.lower()
    scraper = SCRAPERS.get(source_key)
    if scraper is None:
        raise HTTPException(
            status_code=404,
            detail={
                "message": "Fonte não cadastrada",
                "available_sources": sorted(SCRAPERS),
            },
        )

    cache_key = (source_key, limit)
    now = asyncio.get_running_loop().time()
    cached = cache.get(cache_key)
    if cached and now - cached[0] < settings.cache_ttl_seconds:
        return cached[1]

    # Uma única navegação externa por vez reduz CPU, memória e pressão na fonte.
    async with scrape_semaphore:
        now = asyncio.get_running_loop().time()
        cached = cache.get(cache_key)
        if cached and now - cached[0] < settings.cache_ttl_seconds:
            return cached[1]

        try:
            await browser_manager.start()
            if browser_manager.context is None:
                raise ScraperError("Contexto Playwright não foi criado")

            items = await scraper.scrape(browser_manager.context, limit)
        except ScraperError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(
                status_code=503,
                detail=f"Falha ao iniciar ou usar o navegador: {exc}",
            ) from exc

        result = NewsResponse(
            source=scraper.source_name,
            fetched_at=datetime.now(timezone.utc),
            count=len(items),
            items=list(items),
        )
        cache[cache_key] = (asyncio.get_running_loop().time(), result)
        return result


@app.get("/sources")
async def sources() -> dict[str, list[str]]:
    return {"sources": sorted(SCRAPERS)}
