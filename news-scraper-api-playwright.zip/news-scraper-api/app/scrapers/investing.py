from datetime import datetime, timezone
import os
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from playwright.async_api import BrowserContext, Error as PlaywrightError

from app.config import settings
from app.models import NewsItem
from app.scrapers.base import NewsScraper, ScraperError


class InvestingHeadlinesScraper(NewsScraper):
    source_name = "investing"
    page_url = "https://br.investing.com/news/headlines"

    async def scrape(
        self,
        context: BrowserContext,
        limit: int,
    ) -> list[NewsItem]:
        page = await context.new_page()
        page.set_default_timeout(settings.selector_timeout_ms)
        page.set_default_navigation_timeout(settings.navigation_timeout_ms)

        try:
            response = await page.goto(
                self.page_url,
                wait_until="domcontentloaded",
                timeout=settings.navigation_timeout_ms,
            )

            status = response.status if response else None
            if status is not None and status >= 400:
                raise ScraperError(
                    f"Investing respondeu HTTP {status} mesmo com Playwright."
                )

            # O seletor final pode ser ajustado após inspecionar a estrutura real
            # que a Investing entrega para o seu IP/região.
            try:
                await page.wait_for_selector(
                    'a[data-test="article-title"], '
                    'article a[href*="/news/"], '
                    '[data-test="article-list-item"] a[href*="/news/"]',
                    state="attached",
                    timeout=settings.selector_timeout_ms,
                )
            except PlaywrightError:
                # Alguns layouts podem renderizar cards sem o atributo esperado.
                # O HTML ainda será analisado pelos seletores de fallback.
                pass

            if os.getenv("DEBUG_PAUSE", "0") == "1":
                await page.pause()

            html = await page.content()
            return self._parse_html(html, limit)
        except ScraperError:
            raise
        except PlaywrightError as exc:
            raise ScraperError(f"Falha no Playwright ao consultar Investing: {exc}") from exc
        finally:
            await page.close()

    def _parse_html(self, html: str, limit: int) -> list[NewsItem]:
        soup = BeautifulSoup(html, "html.parser")
        items: list[NewsItem] = []
        seen_urls: set[str] = set()

        cards = soup.select(
            'article, [data-test="article-list-item"], '
            '[data-test="article-item"], .articleItem'
        )

        for card in cards:
            anchor = card.select_one(
                'a[data-test="article-title"], '
                'a[href*="/news/"], h2 a, h3 a'
            )
            if not anchor:
                continue

            title = " ".join(anchor.get_text(" ", strip=True).split())
            href = anchor.get("href")
            if not title or not href:
                continue

            item_url = urljoin(self.page_url, href)
            if item_url in seen_urls:
                continue

            items.append(
                NewsItem(
                    title=title,
                    url=item_url,
                    source=self.source_name,
                    published_at=self._parse_datetime(card),
                    summary=self._extract_summary(card),
                )
            )
            seen_urls.add(item_url)

            if len(items) >= limit:
                break

        return items

    @staticmethod
    def _parse_datetime(card) -> datetime | None:
        element = card.select_one(
            "time[datetime], [data-test='article-publish-date']"
        )
        if not element:
            return None

        raw_value = element.get("datetime") or element.get_text(" ", strip=True)
        if not raw_value:
            return None

        try:
            parsed = datetime.fromisoformat(raw_value.replace("Z", "+00:00"))
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            return None

    @staticmethod
    def _extract_summary(card) -> str | None:
        element = card.select_one(
            '[data-test="article-description"], p, .articleItem__summary'
        )
        if not element:
            return None

        summary = " ".join(element.get_text(" ", strip=True).split())
        return summary or None
